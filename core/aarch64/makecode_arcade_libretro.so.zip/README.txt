MakeCode Arcade — libretro core (linux-arm64)

安装：
  先解压本 zip。「安装或恢复核心」的文件浏览器按平台过滤扩展名，只列当前
  平台的核心文件（Windows .dll / Linux .so / macOS .dylib），zip 不在列表里，
  所以解压这一步绕不开。

  方式 A：手动拷贝（推荐，最直接）
    1) 把 makecode_arcade_libretro.so 放进 RetroArch 的「核心」目录，
       把 makecode_arcade_libretro.info 放进「核心信息」目录
       （两者也可以是同一个目录，取决于 RetroArch 的配置）。
       目录的实际位置因平台/发行版而异，请打开
       RetroArch 设置 → 目录 → 核心 / 核心信息 查看你设备上的真实路径，
       不要照搬网上教程里写死的路径。
    2) 有的发行版「核心信息」目录默认与核心目录不同，且菜单里看不到
       该项——先开 设置 → 用户界面 → 显示高级设置，或用配置文件给
       libretro_info_path 赋值。.info 没放对目录时，「加载核心」列表里
       不会出现本核心。

  方式 B：用 RetroArch 安装
    1) 加载核心 → 「安装或恢复核心」→ 选中解压出来的
       makecode_arcade_libretro.so，它会被拷进已配置的核心目录
    2) Install 只拷二进制，.info 不会被带过去——装完确认「核心信息」目录里
       有 makecode_arcade_libretro.info，没有就按方式 A 的第 2 步补上

  3) 加载核心 → 选择 .pxt64 文件

内容格式：
  .pxt64  转换后的 VM 字节码镜像，核心只认这个格式（加载内容里也只列出它）
  .png    MakeCode Arcade 保存的卡带，里面只有源码、不是游戏本身，
          核心不接受这个格式——必须先用 cartconv 转换成 .pxt64
          （cartconv 便携包见 makecode-arcade-cartconv 仓库的 Releases）

功能边界：
  本核心不做即时存档 / 回退（Savestate / Rewind）——RetroArch 的
  「保存状态」「金手指→回退」对本核心不可用（v0.3.0 起明确移除，
  只做官方模拟器同等的基本功能）。「重启游戏」（SELECT 键或前端重启）
  可用来重新开始当前游戏。

排查：
  加载游戏后 RetroArch 日志里会打印
    [MCA] core version 0.3.11, trace -> <路径>
  <路径> 就是 mca_trace.log，记录 VM 启动/重置/卸载的每一步。

  本包里的核心已 strip（去掉调试信息，体积约为原件的 1/5）。如果要把崩溃
  地址翻译回源码行，请下载同版本的 makecode_arcade_linux-arm64-debuginfo.zip，
  按包内 BUILD.txt 用 build-id 对齐后再 addr2line。

目标平台：aarch64-linux-gnu.2.17
core 版本：0.3.11
构建时间：2026-11-20 12:01 UTC
